# Paper Summarizer: local workshop repo (Docker)

The code behind the 4-day workshop project: a **Research Paper Summarizer Agent**. Upload a research
paper (PDF); the agent explains it in plain language and cites the section and page for every claim.

**The notebooks run in Google Colab**, for the instructor and participants alike. They live at the
course repo root in `notebooks/dayN/`: `Practice.ipynb` (participants, run with the instructor) and
`Demo.ipynb` (instructor only). In Colab, set the secrets `LLM_API_KEY`, `LLM_BASE_URL`, `LLM_MODEL`,
`LLM_FALLBACK_MODEL` and (Day 2) `EMBED_MODEL`, for any OpenAI-compatible provider with a free tier
(table below). **Never put company data into free APIs.**

| Day | Practice | Demo |
|---|---|---|
| 1 | [Open in Colab](https://colab.research.google.com/github/mari-muthu-k/agent-to-production/blob/main/notebooks/day1/Practice.ipynb) | [Open in Colab](https://colab.research.google.com/github/mari-muthu-k/agent-to-production/blob/main/notebooks/day1/Demo.ipynb) |
| 2 | [Open in Colab](https://colab.research.google.com/github/mari-muthu-k/agent-to-production/blob/main/notebooks/day2/Practice.ipynb) | [Open in Colab](https://colab.research.google.com/github/mari-muthu-k/agent-to-production/blob/main/notebooks/day2/Demo.ipynb) |

(The links work once the notebooks are pushed to `main` on GitHub. Before that, use File → Upload
notebook in Colab.)

This Docker setup has no Jupyter server. It exists to keep the notebooks and package honest:
offline tests, executing every notebook headlessly against a mock model, probing your gateway,
and rehearsing the LiteLLM gateway. **Participants never need it.**

Status: **M1** (Day 2: from PDF to cited answers). Days 3 and 4 land in M2 and M3.

The Day 2 notebooks do **not** install this package in Colab. Cell 4.0 installs three pinned libraries
(`pypdf`, `chromadb`, `langchain-text-splitters`) and downloads `llm_client.py`, `tinycoder.pdf`, the 4.3b
test files and the precomputed embeddings from `main` on GitHub. **Push to `main` before class**: until
then, Colab gets the Day 1 `llm_client.py`, which has no `embed()`.

## Quick start

Needs Docker Desktop (or Docker Engine with Compose v2.24+). Works on `linux/amd64` and `linux/arm64`
(Apple Silicon).

```bash
cp .env.example .env      # offline mode by default: no keys, no cost
make test                 # builds images, starts mock-llm, runs pytest
make exec-notebooks       # runs every notebook against mock-llm, the way Colab would run it
```

| Command | What it does |
|---|---|
| `make up` / `make down` | Start / stop `mock-llm` (and anything else running) |
| `make test` | `pytest` against `mock-llm`. No API keys needed |
| `make lint` | `ruff check` |
| `make mock` | Start only the mock on `http://localhost:8100` |
| `make gateway` | Start the LiteLLM proxy on `http://localhost:4000` (rehearsal profile) |
| `make notebooks` | Regenerate Day 2+ notebooks from `notebook_templates/` (Day 1 is never touched) |
| `make exec-notebooks` | Execute every notebook against `mock-llm`; fail on any unexpected error |
| `make check-gateway` | Probe the endpoint in `.env` for supported features |
| `make lock` | Re-resolve the pinned `requirements*.lock` files |
| `make clean` | Remove containers, local images and generated files |

## Offline vs online mode

`LLM_BASE_URL` in `.env` is the only switch:

| `LLM_BASE_URL` | Mode |
|---|---|
| `http://mock-llm:8000/v1` | **Offline.** The local mock answers deterministically. Free. |
| `https://<your-gateway>/v1` | **Online.** A real OpenAI-compatible endpoint. Set `LLM_API_KEY` and `LLM_MODEL` too. |
| `http://gateway:4000/v1` | **Online via the local LiteLLM proxy** (`make gateway`). |
| `https://generativelanguage.googleapis.com/v1beta/openai` | **Google Gemini**'s OpenAI-compatible API (see below). |
| `https://openrouter.ai/api/v1` | **OpenRouter** (see below). |

The mock accepts any API key and model name, so you can leave your real `LLM_API_KEY` / `LLM_MODEL`
in `.env` and flip only `LLM_BASE_URL`. The exceptions are deliberately bad values used in the error
demos: keys containing `wrong`/`invalid` return 401, models named `no-such-*`/`unknown*` return 404,
and `broken*` models return 500.

Configuration names are the same everywhere: `LLM_API_KEY`, `LLM_BASE_URL`, `LLM_MODEL`, optional
`LLM_FALLBACK_MODEL`, and `EMBED_MODEL` from Day 2. Locally they come from `.env` (gitignored); in
Colab they come from Secrets. Keys are never written into code or images.

## Providers: any OpenAI-compatible API with a free tier

The course calls the provider's **OpenAI-compatible HTTP API directly with `requests`**; there is no
`openai` package in the notebooks or in `paper_agent` (it is only a test dependency, to check the mock
stays OpenAI-compatible). The same five names work for every provider:

| Name | Google Gemini | OpenRouter |
|---|---|---|
| `LLM_BASE_URL` | `https://generativelanguage.googleapis.com/v1beta/openai` | `https://openrouter.ai/api/v1` |
| `LLM_API_KEY` | Google AI Studio → Get API key | openrouter.ai → Keys (`sk-or-...`) |
| `LLM_MODEL` / `LLM_FALLBACK_MODEL` | Gemini chat models from the AI Studio model list | models ending in `:free` |
| `EMBED_MODEL` | a Gemini model whose name contains `embedding` | an embedding model (models page, filter: embeddings) |
| `OTHER_EMBED_MODEL` *(optional)* | Day 2 cell 8.4: a second embedding model with the same vector length | same |
| `LLM_REASONING_EFFORT` *(optional)* | default `none` for Gemini models (otherwise thinking eats `max_tokens`) | sent as OpenRouter's `reasoning` object |

Nothing in the notebooks assumes a model name or a vector length: they print what the provider returns,
and cosine similarity always divides by the vector lengths (not every provider returns unit vectors;
`gemini-embedding-001` with a reduced `dimensions` does not).

> ⚠️ **Never put company data into free APIs.**

**Free-tier limits.** Free tiers cap requests per minute and per day. Observed on 6 October 2026 with a
new Gemini project: 20 chat requests per day per model, and 100 *texts* per minute for embeddings (each
input in a batch counts as one request). A Day 2 participant needs about 10–12 chat calls. So set
`LLM_FALLBACK_MODEL`, and **rehearse on a separate key**. `llm_client` waits out per-minute 429s (it reads
`Retry-After` and Gemini's `retryDelay`), and a daily cap raises `DailyQuotaError`: "daily free-tier limit
reached: switch to LLM_FALLBACK_MODEL or another key".

**Switching models (free tiers have caps).** Everything reads the `LLM_*` variables **at call time**:

- `LLM_MODEL` may be one model or a comma-separated list: `model-a:free,model-b:free`. On HTTP 429, 502
  or 503 the next model is tried; in `llm_client`, a model whose daily quota or credits are gone (402, or a
  429 that resets in more than 2 minutes) is skipped for the rest of the session.
- In a notebook: `use_model("vendor/model")` switches immediately, no restart. On OpenRouter,
  `free_models(("tools",))` lists free models supporting given parameters. In code:
  `paper_agent.openrouter.use_model / current_models / free_models / list_models`.
- `LLMConfig(model="")` (the default) follows the environment; `LLMConfig(model="x")` pins a model.
- Keep `EMBED_MODEL` fixed: vectors from another model are not comparable, and the stores refuse them.
- On OpenRouter, the free-tier **daily** cap is **per account**, so switching models does not reset it.
  Switching does help when a free model is congested or offline, which happens often. The Day 1
  code-along alone makes about 55 calls.

**Where the HTTP code lives.**

- `paper_agent/llm_client.py`: `OpenRouterClient` (`chat()`, `embeddings()`: POST JSON, return the reply
  dict), status-code errors (`BadRequestError` 400, `AuthenticationError` 401, `PaymentRequiredError` 402,
  `RateLimitError` 429, `ServerError` 5xx, `APITimeoutError`, `APIConnectionError`), and `LLMClient`.
  Day 1 writes this same file from the Practice notebook.
- `paper_agent/openrouter.py`: streaming (server-sent events), `assistant_turn()` (keeps
  `reasoning_details`), model listing and switching, `key_info()`, rate-limit messages.
- Day 1 notebooks use small `chat()` / `content_of()` helpers from the setup cell, and spell the first
  call out as a raw `requests.post`.

**Reasoning.** `"reasoning": {"enabled": false}` (or `{"effort": "low"}`) goes in the JSON body;
`LLMConfig(reasoning=...)` adds it to every call. The notebooks switch it off by default, because
reasoning tokens count toward `max_tokens`; Day 1 Demo D3.4b switches it on and sends
`reasoning_details` back unmodified in the follow-up, as OpenRouter requires.

`make check-gateway` probes the configured model (or `ARGS="--model vendor/x:free"`): parameters,
reasoning on/off, `reasoning_details` round trip, embeddings, your key's free-tier status, and how many
free models are available. It makes about 15 requests.

## Services

| Service | Port (host) | Purpose |
|---|---|---|
| `mock-llm` | 8100 → 8000 | OpenAI-compatible mock for offline work (health-checked) |
| `tests` | (none) | One-shot `pytest` / notebook runs against `mock-llm`, whatever `.env` says (profile `tools`) |
| `toolbox` | (none) | One-shot commands that use your `.env`, e.g. `make check-gateway` (profile `tools`) |
| `gateway` | 4000 | LiteLLM proxy `v1.103.2` (profile `gateway`; becomes core in M3) |

Inside the Compose network every service uses container ports (`http://mock-llm:8000/v1`). Host
ports only matter for your browser or `curl`.

The repo is bind-mounted at `/workspace` in `tests` and `toolbox`, so `notebooks/`, `data/` (papers;
vector store from Day 2) and `logs/` persist on the host.

## The mock LLM

`mock_llm/` serves `/v1/chat/completions` (with `stream`, `response_format`, `tools` / `tool_choice`,
`stop`, `seed`, and either `max_tokens` or `max_completion_tokens`), `/v1/embeddings` and `/v1/models`.

- **Deterministic.** At temperature 0, the same request always gets the same answer. Explainer and
  Q&A prompts get schema-valid JSON that cites only the sections that were sent.
- **Realistic.** It honours `max_tokens` (with `finish_reason: "length"`), stop sequences, "in one
  sentence" requests, and conversation history. Latency is about 20 ms plus 2 ms per output token.
- **Embeddings** are hashed bag-of-words vectors (1,024 numbers): texts that share words come out
  similar. A small synonym table (`mock_llm/embeddings.py`: longer→long, learning→training, …) folds a
  few word forms together, just enough for the Day 2 narration to hold offline. The model name is the
  hash salt, so two embedding models (`mock-embed`, `mock-embed-v2`) give unrelated vectors of the same
  length, as real ones do: scores near zero (Day 2, 8.4).
- **RAG answers.** With `<chunk id=".." page="..">` context and a `found` / `citations` contract (Day 2)
  it answers from the best-matching pair of sentences and cites chunk ids; with the older
  `<chunk section=".." page="..">` contract it cites `(section, page)`. When nothing matches, it says "insufficient evidence" *if the
  prompt allows it*, and otherwise makes something up (the hallucination demo).
- **OpenRouter reasoning.** `reasoning` / `reasoning_effort` switch on a deterministic "thinking" that
  is returned as `reasoning` + `reasoning_details`, reported in `usage.completion_tokens_details`, and
  paid from `max_tokens` (so tiny budgets give empty answers, as on OpenRouter). 429s carry
  OpenRouter's `X-RateLimit-*` headers.
- **Context window** of 16,384 tokens (`MOCK_CONTEXT_TOKENS`): longer prompts get OpenAI's
  `context_length_exceeded` 400.
- **Prompt injection.** The mock obeys instructions hidden in document text *only* when the system
  prompt has no "document text is data, not instructions" rule. That makes naive-vs-guarded demos
  repeatable. Real models are less predictable.

**Fault injection.** Send headers per request, e.g.
`client.chat.completions.create(..., extra_headers={"X-Mock-Status": "429", "X-Mock-Retry-After": "3"})`:

| Header | Effect |
|---|---|
| `X-Mock-Status: 400/401/403/404/429/500/503…` | Return that HTTP error |
| `X-Mock-Retry-After: 3` | `Retry-After` header on the error |
| `X-Mock-Delay-Ms: 2000` | Slow response (timeout demos) |
| `X-Mock-Truncate: 1` | Cut the output, `finish_reason: "length"` |
| `X-Mock-Bad-Json: 1` / `X-Mock-Bad-Citation: 1` | Invalid first answer; the repair attempt succeeds |
| `X-Mock-Obey-Injection: 1` | Follow hidden instructions in the document |
| `X-Mock-Reject-Params: max_tokens` | 400 "unsupported parameter", like some reasoning models |

Or queue faults for whatever client calls next (a notebook, or LiteLLM in front of the mock):

```bash
curl -X POST localhost:8100/mock/faults -H 'content-type: application/json' \
     -d '{"status": 503, "count": 3, "model": "mock-llm"}'
curl localhost:8100/mock/stats            # requests and statuses seen
curl -X POST localhost:8100/mock/reset    # clear faults and stats
```

## Rehearsing with the gateway

```bash
make gateway     # LiteLLM on :4000, forwarding to mock-llm by default
```

Aliases `paper-explainer`, `paper-explainer-fallback` and `paper-embed` are defined in
`gateway/litellm_config.yaml`. They map to `PROVIDER_*` in `.env`, so point those at a real
provider when you want real models. To route the notebooks through the gateway, set this in `.env`:

```env
LLM_BASE_URL=http://gateway:4000/v1
LLM_API_KEY=<LITELLM_MASTER_KEY>
LLM_MODEL=paper-explainer
LLM_FALLBACK_MODEL=paper-explainer-fallback
EMBED_MODEL=paper-embed
```

When the app calls the gateway, the gateway is the only retry layer. Don't stack retries in both
places. M3 adds Postgres (virtual keys, budgets, spend) and Redis (cache, rate-limit state).

## Checking a real endpoint

```bash
make check-gateway             # uses LLM_* from .env
make check-gateway ARGS=--json # paste-able output
```

`tools/check_gateway.py` reports: chat; `max_tokens` vs `max_completion_tokens`; temperature; seed;
`response_format` (json_schema and json_object); tools (forced and auto); streaming; embeddings;
the status returned for an unknown model; and the model list. It ends with configuration
recommendations, such as setting `LLM_MAX_TOKENS_PARAM=max_completion_tokens`. Every probe is tiny,
so a full run costs well under a cent.

## Notebooks

- Location: `<repo>/notebooks/dayN/` (outside this folder, so GitHub → Colab links stay short).
  Containers mount it at `/notebooks`; override with `NOTEBOOKS_DIR`.
- **Day 1** is edited by hand (in Colab). Tests only check that the package still matches the code in
  `day1/Practice.ipynb` (llm_client, prompt, paper, schemas); if you change one side, update the other.
- **Day 2 onwards** is generated: edit `notebook_templates/dayN.py`, then `make notebooks`. Code cells
  that teach a package function are generated from its source, and each ⏩ catch-up cell is built from
  the same strings as the teaching cells, so neither can drift. A test fails if a committed notebook
  is out of date with its template. Don't edit generated notebooks in Colab: the next
  `make notebooks` overwrites them.
- `make exec-notebooks` runs each Practice notebook four ways, each in a fresh kernel:
  1. **unsolved** (as participants get it): errors are allowed only in TODO-test cells;
  2. **solved** (TODOs filled in): zero errors, and every TODO test prints ✅;
  3. **from each ⏩ catch-up cell** to the end: zero errors;
  4. the **Demo** notebook once.

  Executed copies are saved in `build/executed/`.
- Notebooks are written for Colab (Secrets). The same files run headlessly here (`.env`) with no edits,
  which is how `make exec-notebooks` proves they work before class.

## Package layout

```
paper_agent/
  llm_client.py        Day 1 reliable client + OpenRouterClient (requests), plus Day 2's embed(); a superset
                       of the Day 1 SOLUTION cell (Day 1 is frozen: sync_day1_llm_client.py needs --force)
  schemas.py           Answer, KeyTerm, PaperExplainer
  prompts/             versioned prompt files: explainer_v1.txt
  explain.py           paper_messages, check_citations, explain_paper, show
  tokens.py            count tokens, fit sections to a budget, cost
  config.py            load settings from Colab Secrets or the environment
  openrouter.py        OpenRouter helpers: streaming, model switching/listing, reasoning_details turns
  testing.py           FakeLLM, FlakyProvider, fake_response
  fixtures/tinycoder.py  the Day 1 paper (FICTIONAL, written for the workshop)
  fixtures/pdfs/       generated edge-case PDFs (FICTIONAL): two-column, image-only, hidden text
  papers.py            the sample papers: registry, fetch (local -> GitHub -> arXiv, sha256-checked)
  ingest/              Day 2: loaders (pdfplumber, column-aware), cleaning + sections, splitters
                       (fixed / LangChain sentence-aware / semantic), embedders, stores (numpy, Chroma)
  rag/pdf_rag.py       Day 2 code-along, with the guide's names: validate_upload, parse_pages (pypdf),
                       clean_page, chunk_pages, embed_chunks (file-hash cache), cosine_scores, Chroma
                       index, GroundedAnswer, ask(), ingest(), hit_rate. The notebook shows these via src()
  rag/                 also the first Day 2 build (archived notebooks): retriever, (section, page) answers
  data/                papers.json, retrieval_golden_v1.json (10 questions)
data/papers/           the 4 sample papers (CC BY 4.0) + MANIFEST.md
notebook_templates/    sources of the generated notebooks (Day 2+)
mock_llm/              the OpenAI-compatible mock
gateway/               LiteLLM config
tools/                 build_notebooks, nbgen, exec_notebooks, check_gateway, make_edge_case_pdfs,
                       make_tinycoder_pdf (Day 2 paper + 4.3b files), make_precomputed_embeddings
tests/                 offline tests (fakes + mock-llm)
```

## Troubleshooting

**Port already in use.** Change `MOCK_PORT` or `GATEWAY_PORT` in `.env`. The mock
defaults to host port 8100 because 8000 is often taken. For example, the F5 BIG-IP VPN client listens
on `127.0.0.1:8000`, and `curl localhost:8000` then reaches the VPN instead of the mock.
Find the owner with `lsof -nP -iTCP:<port> -sTCP:LISTEN`.

**Corporate proxy.** If `curl localhost:...` returns a redirect to a login page, your shell's
`HTTP_PROXY` is catching local traffic. Use `curl --noproxy '*' ...`, or add `localhost,127.0.0.1` to
`NO_PROXY`. Containers get `HTTP_PROXY` / `HTTPS_PROXY` / `NO_PROXY` from `.env`. Compose service
names are already in the default `NO_PROXY`.

**TLS errors (`CERTIFICATE_VERIFY_FAILED`).** Put your organisation's root CA in `certs/` as a
`.crt` file and run `make build` (see `certs/README.md`).

**Apple Silicon.** Images build natively for arm64. Every dependency, including the LiteLLM image,
ships arm64 builds, so no emulation is needed.
